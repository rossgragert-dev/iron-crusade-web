/* Iron Crusade v0.5.0-alpha.9b — THE FORGE EXPANSE.
 * A standalone geometry/collision/nav extension of the approved alpha.9 playable build.
 * Kept byte-for-byte identical between editable source/public and packaged dist.
 * Uses the existing public window.__IC API so no external JS dependency is required.
 */
(function () {
  'use strict';
  const VERSION='0.5.0-alpha.9b';
  const HALF_X=350, HALF_Z=370;
  const ORIGINAL_AREA={halfX:109,halfZ:115};
  const SPAWNS=[[-1,-10],[170,-33],[-180,-33],[0,-255],[0,265],[210,226]];
  const MOBILE=(typeof matchMedia==='function'&&matchMedia('(pointer: coarse)').matches)||new URLSearchParams(location.search).get('mobile')==='1';
  let seed=0x3e91a417;
  function rand(){seed ^= seed<<13;seed ^= seed>>>17;seed ^= seed<<5;return(seed>>>0)/4294967296;}
  function range(lo,hi){return lo+(hi-lo)*rand();}
  function clamp(n,a,b){return Math.min(b,Math.max(a,n));}
  const SECTORS=[
    {name:'CENTRAL FORGE',x:0,z:0,r:110},
    {name:'BASTION QUARTER',x:-240,z:75,r:180},
    {name:'REACTOR YARDS',x:245,z:-90,r:180},
    {name:'NORTHERN WORKS',x:0,z:250,r:150},
    {name:'SOUTHERN WASTES',x:0,z:-260,r:155},
    {name:'ASHEN REDOUBT',x:230,z:270,r:145},
  ];
  function district(x,z){
    if(Math.abs(x)<113&&Math.abs(z)<118)return'STRIKE ZONE · CENTRAL FORGE';
    if(z>155&&x>116)return'ASHEN REDOUBT';
    if(z>140)return'NORTHERN WORKS';
    if(z<-135)return'SOUTHERN WASTES';
    if(x<0)return'BASTION QUARTER';
    return'REACTOR YARDS';
  }
  function install(api){
    if(!api || api.expanse || !api.scene || !api.arena || !api.siege?.props?.length || !api.enemies?.length || !api.camera)return false;
    const {scene,arena,siege,camera,MAT,enemies,state}=api;
    const standardWall=siege.props.find(p=>p.type==='BARRICADE');
    const boxGeo=standardWall?.parts?.wall?.geometry;
    let existing=null;
    scene.traverse(o=>{if(!existing&&o.isInstancedMesh)existing=o;});
    if(!boxGeo || !existing)return false;
    const InstancedMesh=existing.constructor;
    const Matrix4=camera.matrix.constructor;
    const Vec3=camera.position.constructor;
    const Quat=camera.quaternion.constructor;
    const m=new Matrix4(),v=new Vec3(),s=new Vec3(),q=new Quat();
    const up=new Vec3(0,1,0);
    const groups=new Map(),visibleGroups=[],allMeshes=[],buildings=[];
    let sceneryInstances=0;
    function add(material,x,y,z,w,h,d,rot=0){
      if(!material || w<=0 || d<=0)return;
      const sector= (Math.floor((x+HALF_X)/175)) + ':' + (Math.floor((z+HALF_Z)/185));
      const key=sector+':'+(material.uuid||material.id);
      let g=groups.get(key);
      if(!g){g={material,sector,x:Math.floor((x+HALF_X)/175)*175-HALF_X+87.5,z:Math.floor((z+HALF_Z)/185)*185-HALF_Z+92.5,boxes:[]};groups.set(key,g);}
      g.boxes.push([x,y,z,w,h,d,rot]);
    }
    function make(mat,boxes,name){
      const mesh=new InstancedMesh(boxGeo,mat,boxes.length);
      mesh.name=name;mesh.frustumCulled=false;mesh.castShadow=false;mesh.receiveShadow=false;
      boxes.forEach((a,i)=>{
        q.setFromAxisAngle(up,a[6]||0);
        m.compose(v.set(a[0],a[1],a[2]),q,s.set(a[3],a[4],a[5]));
        mesh.setMatrixAt(i,m);
      });
      mesh.instanceMatrix.needsUpdate=true;
      scene.add(mesh);allMeshes.push(mesh);sceneryInstances+=boxes.length;
      return mesh;
    }
    // Ground is continuous (no holes or fall-through). The central alpha.9 ground
    // sits 1.5 cm above it so its original surfaces are unchanged.
    make(MAT.earth,[[0,-.332,0,704,.5,744]],'Expanse continuous foundation');
    const road=[];
    function path(x,z,w,d){road.push([x,-.012,z,w,.11,d]);}
    path(0,-238,16,258);path(0,240,16,260);
    path(-230,-33,242,16);path(230,-33,242,16);
    path(0,226,704,17);path(0,-243,704,17);
    path(-210,0,17,744);path(210,0,17,744);
    make(MAT.road,road,'Expanse navigable arterial roads');
    const markings=[];
    for(const laneZ of [-243,-33,226]){
      for(let x=-342;x<=340;x+=23){
        if(laneZ===-33 && Math.abs(x)<103)continue;
        markings.push([x,.054,laneZ,5,.01,.16]);
      }
    }
    for(const laneX of [-210,0,210]){
      for(let z=-356;z<=356;z+=24){
        if(laneX===0&&Math.abs(z)<109)continue;
        markings.push([laneX,.054,z,.16,.01,5]);
      }
    }
    make(MAT.bone,markings,'Expanse route markings');

    function isRoad(x,z,clearance=13){
      return Math.abs(x)<clearance||Math.abs(x-210)<clearance||Math.abs(x+210)<clearance ||
       Math.abs(z+33)<clearance||Math.abs(z+243)<clearance||Math.abs(z-226)<clearance;
    }
    function tower(x,z,w,d,h,type=0){
      const b={x,z,w,d,h,minX:x-w/2,maxX:x+w/2,minZ:z-d/2,maxZ:z+d/2};
      if(isRoad(x,z,Math.max(w,d)/2+12))return;
      buildings.push(b);
      add(MAT.wallDark,x,h/2,z,w,h,d);
      add(MAT.wall,x,h-.22,z,w+.7,.75,d+.7);
      for(const side of [-1,1]){
        const za=z+side*(d/2+.12);
        for(let k=0;k<(MOBILE?2:4);k++){
          const px=x+(k+1)*w/(MOBILE?3:5)-w/2;
          add(k%2?MAT.steel:MAT.wall,px,h*.55,za,.65,h*.65,.3);
          if(type%2===0)add(MAT.panel,px,h*.65,za,1.1,1.4,.13);
        }
      }
      for(const side of [-1,1]){
        const xx=x+side*(w/2-.7);
        add(MAT.wall,xx,h/2,z,.9,h,.9);
      }
      if(type%3===0){
        add(MAT.steel,x,h+1.3,z,w*.72,2,d*.7);
        add(MAT.wallDark,x,h+4,z,w*.28,4,d*.25);
      }else if(type%3===1){
        add(MAT.steel,x,h+1,z,w*.85,2,d*.85);
        add(MAT.dark,x,h+3.4,z,2.4,3.5,2.4);
      }
    }
    const X=[-305,-262,-159,-116,116,159,262,305];
    const Z=[-325,-282,-164,-121,120,166,274,321];
    let id=0;
    for(const x of X){for(const z of Z){
      if(Math.abs(x)<180 && Math.abs(z)<130)continue; // preserve existing central district
      const dx=x+range(-5,5),dz=z+range(-5,5);
      const w=range(14,22),d=range(13,22),h=range(11,34);
      tower(dx,dz,w,d,h,id++);
    }}
    // Four landmark silhouettes: a collapsed forge shrine, an engine relay,
    // a northern smoke-stack cluster and the walled redoubt.
    const landmarks=[
      [-270,77,'BASTION SHRINE'],[280,-150,'REACTOR RELAY'],[-75,289,'NORTH STACKS'],[267,268,'ASHEN REDOUBT']
    ];
    for(const [x,z,label] of landmarks){
      for(let k=0;k<4;k++){
        const ox=(k%2?1:-1)*range(4,11),oz=(k<2?-1:1)*range(4,11);
        add(MAT.steel,x+ox,range(7,11),z+oz,range(1.8,3.3),range(16,24),range(1.8,3.3));
      }
      add(MAT.brass,x,16,z,5,2,5);
      add(MAT.wallDark,x,13,z,2,9,2);
    }
    // Cosmetic roadside props. Keep lanes clean. Dense details are batched and
    // never create extra collision objects / per-frame allocations.
    for(let i=0;i<(MOBILE?230:430);i++){
      const x=range(-337,337),z=range(-356,356);
      if(Math.abs(x)<108&&Math.abs(z)<116 || isRoad(x,z,21))continue;
      const w=range(.45,2.2),d=range(.45,2.3);
      add(i%4===0?MAT.steel:MAT.wallDark,x,w*.13,z,w,w*.25,d,range(-3,3));
    }
    let numChunks=0;
    for(const g of groups.values()){
      const mesh=make(g.material,g.boxes,'Expanse '+g.sector);
      visibleGroups.push({mesh,x:g.x,z:g.z});numChunks++;
    }
    const oldCollision=arena.collideBuildings.bind(arena);
    const oldRay=arena.rayBuildings.bind(arena);
    // buildArena() returns its ACTUAL collision/raycast AABB array on the API.
    // Append the new structures to that same list so the game's native rayAABB
    // handles line-of-sight, impact surface normals, foot movement and cameras.
    // This is safer than maintaining a duplicate JS raycaster for the preview.
    const centralBuildingCount=arena.buildings.length;
    arena.buildings.push(...buildings);
    function bounds(x,z,r=0){return x<-HALF_X+r || x>HALF_X-r || z<-HALF_Z+r || z>HALF_Z-r;}
    arena.collideBuildings=function(x,z,r){
      if(bounds(x,z,r))return true;
      for(const b of arena.buildings){
        if(x>b.minX-r&&x<b.maxX+r&&z>b.minZ-r&&z<b.maxZ+r)return true;
      }
      return false;
    };
    // The original rayBuildings() sees all appended AABBs via its closure, and
    // still writes the shared hitNormal used by weapon impact effects.
    arena.expanseBuildings=buildings;
    arena.expanseHalfX=HALF_X;arena.expanseHalfZ=HALF_Z;
    camera.far=Math.max(camera.far,790);camera.updateProjectionMatrix();
    if(scene.fog && typeof scene.fog.density==='number')scene.fog.density=MOBILE?.0062:.0057;
    // Draw the expanded world by nearby chunks, never all ~600 instances at once.
    function updateChunks(){
      const p=api.walker.pos;
      for(const c of visibleGroups)c.mesh.visible=Math.abs(c.x-p.x)<280&&Math.abs(c.z-p.z)<290;
    }
    updateChunks();
    // Six enemies still drive the existing mission/kill counter. Locate them
    // along real, unobstructed road approaches around the expanded battlefield.
    // Patching reset once maintains their positions on every chassis switch/redeploy.
    enemies.forEach((en,i)=>{
      if(i>=SPAWNS.length)return;
      const oldReset=en.reset.bind(en),[sx,sz]=SPAWNS[i];
      en.spawn={x:sx,z:sz};
      en.reset=function(_x,_z,yaw){
        return oldReset(sx,sz,Math.atan2(sx,sz-33));
      };
      if(state.mode==='menu'||state.mode==='ended')en.reset(sx,sz,0);
    });
    // HUD navigation is pure presentation; the game still controls actual
    // movement, combat, objective state, and difficulty.
    const host=document.createElement('div');
    host.id='expanseNav';
    host.innerHTML='<button id="expanseMapBtn" aria-expanded="false">⌖ MAP <span>▾</span></button><div id="expanseNavLine">WORLD DATA LINK</div><div id="expanseMapPane" hidden><canvas id="expanseMapCanvas" width="184" height="194" aria-label="World map with player and hostiles"></canvas><div class="expanseMapLegend">◆ WALKER · <b>●</b> HOSTILES · ◇ LANDMARKS</div></div>';
    const style=document.createElement('style');style.textContent=`
      #expanseNav{position:absolute;right:14px;top:207px;z-index:8;color:#dbe9e7;font:700 11px Rajdhani,system-ui,sans-serif;letter-spacing:.7px;text-align:right;pointer-events:none;text-shadow:0 1px 3px #000;}
      #expanseNav button{pointer-events:auto;background:#0b202cdb;color:#e8d2a4;border:1px solid #bc9c6a;border-radius:4px;padding:7px 13px;min-height:33px;font:800 12px Rajdhani,system-ui,sans-serif;letter-spacing:1.4px;touch-action:manipulation;}
      #expanseNavLine{margin-top:4px;color:#cde8e5;background:#071b25bf;padding:3px 6px;border-radius:3px;max-width:192px;margin-left:auto;line-height:1.2;}
      #expanseMapPane{pointer-events:auto;background:#08161cde;border:1px solid #856e4a;border-radius:5px;margin-top:5px;padding:6px;width:198px;box-shadow:0 3px 15px #000a;}
      #expanseMapPane[hidden]{display:none}
      #expanseMapCanvas{width:184px;height:194px;display:block;touch-action:none;background:#101d22;border:1px solid #33434a;}
      .expanseMapLegend{color:#b1bebc;font-size:9px;letter-spacing:.1px;margin-top:4px;text-align:center}
      .expanseMapLegend b{color:#ef755f}
      @media(pointer:fine){#expanseNav{top:144px;right:28px}}
      @media(max-height:530px){#expanseNav{top:111px}}
    `;
    document.head.append(style);document.querySelector('#hud')?.append(host);
    const toggle=host.querySelector('#expanseMapBtn'),panel=host.querySelector('#expanseMapPane');
    const cv=host.querySelector('#expanseMapCanvas'),ctx=cv.getContext('2d');
    const tW=170,tH=172,x0=7,y0=7;
    function px(x){return x0+(x+HALF_X)/(HALF_X*2)*tW;}
    function py(z){return y0+(z+HALF_Z)/(HALF_Z*2)*tH;}
    let mapOpen=!MOBILE;
    function setOpen(v){mapOpen=v;panel.hidden=!v;toggle.setAttribute('aria-expanded',String(v));toggle.innerHTML=v?'⌖ MAP <span>▴</span>':'⌖ MAP <span>▾</span>';}
    setOpen(mapOpen);
    toggle.addEventListener('click',()=>setOpen(!mapOpen));
    function draw(){
      if(!ctx || !mapOpen)return;
      ctx.fillStyle='#17292d';ctx.fillRect(0,0,184,194);
      ctx.fillStyle='#26363a';ctx.fillRect(x0,y0,tW,tH);
      ctx.strokeStyle='#475b5e';ctx.lineWidth=3;
      for(const x of [-210,0,210]){ctx.beginPath();ctx.moveTo(px(x),y0);ctx.lineTo(px(x),y0+tH);ctx.stroke();}
      for(const z of [-243,-33,226]){ctx.beginPath();ctx.moveTo(x0,py(z));ctx.lineTo(x0+tW,py(z));ctx.stroke();}
      ctx.strokeStyle='#a58359';ctx.lineWidth=1.5;ctx.strokeRect(px(-109),py(-115),px(109)-px(-109),py(115)-py(-115));
      ctx.fillStyle='#a2a0a0';
      for(const [x,z] of landmarks){ctx.beginPath();ctx.moveTo(px(x),py(z)-3);ctx.lineTo(px(x)+3,py(z));ctx.lineTo(px(x),py(z)+3);ctx.lineTo(px(x)-3,py(z));ctx.closePath();ctx.fill();}
      for(const e of enemies){if(!e.alive)continue;ctx.beginPath();ctx.fillStyle='#fb8267';ctx.arc(px(e.pos.x),py(e.pos.z),3,0,Math.PI*2);ctx.fill();}
      const x=px(api.walker.pos.x),y=py(api.walker.pos.z),yaw=api.cameraRig.yaw;
      ctx.save();ctx.translate(x,y);ctx.rotate(-yaw);ctx.fillStyle='#82e8e2';ctx.beginPath();ctx.moveTo(0,-7);ctx.lineTo(5,5);ctx.lineTo(0,2);ctx.lineTo(-5,5);ctx.closePath();ctx.fill();ctx.restore();
      ctx.textAlign='center';ctx.fillStyle='#bbd0c8';ctx.font='10px Rajdhani, sans-serif';ctx.fillText('N',92,190);
    }
    let active=true,old=0;
    function tick(now){
      if(!active||window.__IC!==api)return;
      requestAnimationFrame(tick);
      if(now-old<220)return;old=now;
      updateChunks();
      const p=api.walker.pos,targets=enemies.filter(e=>e.alive);
      targets.sort((a,b)=>Math.hypot(a.pos.x-p.x,a.pos.z-p.z)-Math.hypot(b.pos.x-p.x,b.pos.z-p.z));
      const t=targets[0],d=t?Math.hypot(t.pos.x-p.x,t.pos.z-p.z):0;
      host.querySelector('#expanseNavLine').textContent=district(p.x,p.z)+' · '+(t?Math.round(d)+'m TO CONTACT':'AREA CLEAR');
      host.style.display=state.mode==='playing'?'':'none';
      draw();
    }
    requestAnimationFrame(tick);
    api.expanse={version:VERSION,enabled:true,dimensions:[HALF_X*2,HALF_Z*2],originalArea:[ORIGINAL_AREA.halfX*2,ORIGINAL_AREA.halfZ*2],areaScale: (HALF_X*2*HALF_Z*2)/(ORIGINAL_AREA.halfX*2*ORIGINAL_AREA.halfZ*2),
      regions:SECTORS.map(s=>s.name),newBuildings:buildings.length,sceneryInstances,renderChunks:numChunks,
      enemyPositions:SPAWNS.map(p=>p.slice()),getMapOpen:()=>mapOpen,toggleMap:()=>setOpen(!mapOpen),
      collide:(x,z,r)=>arena.collideBuildings(x,z,r),ray:(...args)=>arena.rayBuildings(...args),
      destroy(){active=false;host.remove();style.remove();allMeshes.forEach(o=>{scene.remove(o);o.dispose?.();});arena.collideBuildings=oldCollision;arena.buildings.length=centralBuildingCount;delete api.expanse;}
    };
    return true;
  }
  function boot(){
    if(!install(window.__IC))requestAnimationFrame(boot);
  }
  boot();
})();
