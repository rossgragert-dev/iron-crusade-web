/* Iron Crusade alpha.8 preview: additive cinematic extension to approved alpha.7e runtime.
   Uses existing pooled FX without per-shot GPU asset allocation. It does not change
   damage, cooldown, enemy AI, controls or camera-targeting math. */
(function () {
  'use strict';
  const cyan=[0.5,0.92,1], white=[1,1,1], fire=[1,0.66,0.28], ember=[1,0.38,0.1], spark=[1,0.82,0.45];
  let audioContext=null;
  function playWeaponSound(kind, volume) {
    if (!window.AudioContext && !window.webkitAudioContext) return false;
    try {
      if (!audioContext) audioContext=new (window.AudioContext||window.webkitAudioContext)();
      if (audioContext.state==='suspended') audioContext.resume();
      const now=audioContext.currentTime, v=Math.max(.05,Math.min(1,volume||1));
      const layers=kind==='plasma' ? [[590,160,.17,.08,'sawtooth'],[180,49,.23,.17,'sine']]
        : [[220,58,.08,.12,'square'],[84,32,.14,.19,'sine']];
      for (const [f0,f1,dur,loud,type] of layers) {
        const osc=audioContext.createOscillator(), gain=audioContext.createGain();
        osc.type=type;osc.frequency.setValueAtTime(f0,now);
        osc.frequency.exponentialRampToValueAtTime(f1,now+dur);
        gain.gain.setValueAtTime(loud*v,now);
        gain.gain.exponentialRampToValueAtTime(.0001,now+dur);
        osc.connect(gain).connect(audioContext.destination);osc.start(now);osc.stop(now+dur+.015);
      }
      return true;
    }catch(_){return false;}
  }
  function install(api) {
    if (api.__alpha8) return;
    api.__alpha8=true;
    const fx=api.fx, combat=api.combat, cameraRig=api.cameraRig;
    // Contact effects are world-space and use the existing particle pools. The shot
    // tracer supplied by combat.shoot is the definitive muzzle -> hit direction.
    const oldShoot=combat.shoot;
    combat.shoot=function(weaponId='autocannon') {
      const wasTrace=fx.tracer, wasPlay=api.audio.play;
      let hit=null;
      fx.tracer=function(from,to,width,red,duration,length,glowing) {
        wasTrace.call(fx,from,to,width,red,duration,length,glowing);
        if(weaponId==='lascannon'){
          // Two co-aligned luminous streaks, recycled from the existing tracer pool.
          wasTrace.call(fx,from,to,.35,false,.21,92,true);
          wasTrace.call(fx,from,to,.075,false,.22,90,true);
          fx.glow.spawn(from.x,from.y,from.z,0,0,0,.16,1.65,.24,white,.98,cyan,0,1.3,0);
          const dx=to.x-from.x,dy=to.y-from.y,dz=to.z-from.z;
          const len=Math.hypot(dx,dy,dz)||1;
          fx.glow.spawn(from.x,from.y,from.z,dx/len*8,dy/len*8,dz/len*8,.23,1.35,.14,cyan,.8,white,0,1.4,0);
        }else if(weaponId==='autocannon'){
          const dx=to.x-from.x,dy=to.y-from.y,dz=to.z-from.z;
          const len=Math.hypot(dx,dy,dz)||1;
          fx.glow.spawn(from.x,from.y,from.z,dx/len*8,dy/len*8,dz/len*8,.17,1.4,.23,white,.96,cyan,0,1.4,0);
          fx.glow.spawn(from.x,from.y,from.z,dx/len*5,dy/len*5,dz/len*5,.24,1,.17,cyan,.77,white,0,1.4,0);
        }
        if(weaponId==='lascannon'||weaponId==='autocannon'){
          // lastKind is assigned immediately after tracer returns, so read it afterwards.
          hit={x:to.x,y:to.y,z:to.z};
        }
      };
      api.audio.play=function(kind,v){
        if(kind==='fire'&&(weaponId==='autocannon'||weaponId==='bolter')) {
          if(!api.audio.enabled)return;
          if(playWeaponSound(weaponId==='autocannon'?'plasma':'bolter',v)) return;
        }
        return wasPlay.call(api.audio,kind,v);
      };
      try { return oldShoot.apply(this,arguments); }
      finally {
        fx.tracer=wasTrace;api.audio.play=wasPlay;
        // Distinct feel while never moving the authoritative reticle / combat ray.
        cameraRig.kick(weaponId==='lascannon'?.48:weaponId==='autocannon'?.22:.12);
        if(hit&&combat.stats.lastKind!=='miss') {
          fx.glow.spawn(hit.x,hit.y,hit.z,0,0,0,
            weaponId==='lascannon'?.33:.17,weaponId==='lascannon'?2.2:1.1,.24,
            white,.94,cyan,0,1.2,0);
          fx.sparks(hit.x,hit.y,hit.z,0,.35,0,
            weaponId==='lascannon'?12:4,weaponId==='lascannon'?13:7,cyan);
          if(weaponId==='lascannon'&&hit.y<2.8) fx.ring(hit.x,.17,hit.z,3.2,.36,'#a3edff',.4);
        }
      }
    };
    // Footfall and charge animation enhancement on the existing rigs. Hook once
    // per walker instance, including chassis constructed later in the Armory.
    function enhanceWalker(w){
      if(!w||w.__alpha8)return;
      w.__alpha8=true;
      const oldLand=w._onLand;
      w._onLand=function(foot,strength){
        oldLand.call(this,foot,strength);
        const m=this.key==='BRUTALIS'?1.18:this.key==='BALLISTUS'?1.05:.87;
        fx.dust(foot.px,.14,foot.pz,Math.max(.45,Math.min(1.7,strength))*m*.7,2);
        if(strength>.75&&fx.density>.65)fx.ring(foot.px,.12,foot.pz,1.8*m,.23,'#a89b8b',.18);
      };
      const oldMelee=w.startMelee;
      const tip=w.pos.clone();
      w.startMelee=function(yaw){
        const accepted=oldMelee.call(this,yaw);
        if(accepted){
          this.fistWorld(tip);
          fx.glow.spawn(tip.x,tip.y,tip.z,0,.3,0,.23,this.key==='BRUTALIS'?1.2:1,.2,
            cyan,.75,white,0,1.5,0);
        }
        return accepted;
      };
      if(w.key==='BRUTALIS'){
        const oldTick=w.arms.tick;
        let wake=0;
        w.arms.tick=function(dt){
          oldTick.call(this,dt);
          if(this.charge.phase==='dash'){
            wake-=dt;
            if(wake<=0){
              wake=.14;
              const c=this.charge;
              const x=w.pos.x-c.dirX*2.5,z=w.pos.z-c.dirZ*2.5;
              fx.dust(x,.17,z,1.5,3);
              if(fx.density>.5)fx.sparks(x,.5,z,0,.2,0,3,5,spark);
            }
          }else wake=0;
        };
      }
    }
    const walkers=api.walkers||{};
    Object.values(walkers).forEach(enhanceWalker);
    let now=0;
    function hookLater(t){
      if(t-now>1000){now=t;Object.values(walkers).forEach(enhanceWalker);}
      if(window.__IC===api)requestAnimationFrame(hookLater);
    }
    requestAnimationFrame(hookLater);
    // Inform QA scripts that this is the preview-only, binary-safe enhancement.
    api.alpha8={version:'0.5.0-alpha.8',kind:'runtime-effects-preview',visualOnly:true,
      features:['plasma','laser','bolter-audio','hydraulics','brutalis-charge','camera-kick']};
  }
  function boot(){ if(window.__IC) install(window.__IC); else requestAnimationFrame(boot); }
  boot();
})();
