/* Iron Crusade 0.5.0-alpha.9 — Ashes of the Forge: Battlefield aftermath.
 * Install against the stable public gameplay API. This identical module is used
 * by both the editable source and the Cloudflare preview (no shader dependency).
 * All added scenery is render-only: no collision or targeting mutations.
 * Fixed-capacity GPU-instanced details/debris, deterministic independent seed.
 */
(function () {
  'use strict';
  const VERSION = '0.5.0-alpha.9';
  const qs = new URLSearchParams(location.search);
  const OFF = qs.get('environment') === 'off';
  const MOBILE = (typeof matchMedia === 'function' && matchMedia('(pointer: coarse)').matches) || qs.get('mobile') === '1';
  const LOW = MOBILE || qs.get('battleDetail') === 'low';
  const DEG = Math.PI / 180;
  const density = LOW ? 0.58 : 1;
  let seed = 91237019;
  function rand() { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return (seed >>> 0) / 4294967296; }
  function between(a,b) { return a + rand() * (b-a); }

  function install(api) {
    if (!api || api.alpha9) return;
    if (OFF) {
      api.alpha9 = { version: VERSION, enabled: false, reason: 'environment=off', visualOnly: true };
      return;
    }
    const { scene, siege, arena, MAT, camera, fx } = api;
    if (!scene || !siege || !arena || !siege.props.length || !camera || !MAT) return;
    const wall = siege.props.find(p => p.type === 'BARRICADE');
    const boxGeo = wall?.parts?.wall?.geometry;
    let instancedExample = null;
    scene.traverse(obj => { if (!instancedExample && obj.isInstancedMesh) instancedExample = obj; });
    if (!boxGeo || !instancedExample) return;
    const InstancedMesh = instancedExample.constructor;
    const Vec3 = camera.position.constructor;
    const Matrix4 = camera.matrix.constructor;
    const Quat = camera.quaternion.constructor;
    const m = new Matrix4(), v = new Vec3(), scale = new Vec3(), q = new Quat();
    const axisY = new Vec3(0, 1, 0);
    const sceneDetails = [];
    const groups = new Map();
    function detail(mat, x, y, z, sx, sy, sz, yaw = 0, tilt = 0) {
      let list = groups.get(mat);
      if (!list) groups.set(mat, (list = []));
      list.push([x,y,z,sx,sy,sz,yaw,tilt]);
    }
    function compose(d) {
      const [x,y,z,sx,sy,sz,yaw,tilt] = d;
      q.setFromAxisAngle(axisY, yaw || 0);
      if (tilt) q.multiply(new Quat().setFromAxisAngle(new Vec3(0,0,1),tilt));
      return m.compose(v.set(x,y,z),q,scale.set(sx,sy,sz));
    }
    function batch(mat, entries, name) {
      if (!entries.length) return null;
      const mesh = new InstancedMesh(boxGeo, mat, entries.length);
      mesh.name = name;
      mesh.frustumCulled = false; // instance matrices span many blocks
      mesh.castShadow = false;
      mesh.receiveShadow = false;
      entries.forEach((d,i) => mesh.setMatrixAt(i, compose(d)));
      mesh.instanceMatrix.needsUpdate = true;
      scene.add(mesh);
      sceneDetails.push(mesh);
      return mesh;
    }
    // Architectural surface depth: damage-visible wall ribs, parapet teeth,
    // ruined buttresses and shutter slits. Project < 0.6m outside the already
    // solid building bounds so decorative meshes do not affect LOS or collision.
    for (const b of arena.buildings || []) {
      const facadeCount = LOW ? 4 : 7;
      for (const side of [-1,1]) {
        const z = b.z + side*(b.d/2 + 0.26);
        for (let j=0; j<facadeCount; j++) {
          const x = b.x + between(-b.w*0.40,b.w*0.40);
          const h = between(3.7,b.h-2);
          const wi = between(.3,1.15), he = between(1.2,2.8);
          detail(j%4 ? MAT.wallDark : MAT.panel,x,h,z,wi,he,.19,0,between(-.035,.035));
          if (j%3===0) detail(MAT.steel,x,h+he*.5,z+side*.09,wi*1.2,.10,.27);
        }
        // Heavy flying buttress impression at corners, above the ground plane.
        for (const sign of [-1,1]) {
          const x = b.x + sign*(b.w/2-0.8);
          detail(MAT.wall,x,between(6,9),z,between(.6,1),between(6,10),.63,0,sign*.075);
        }
        for(let k=0;k<(LOW?3:5);k++){
          const x=b.x-b.w*.39+(k+.5)*b.w/(LOW?3:5);
          detail(MAT.wall,x,b.h+.6,z,between(.65,1.2),between(.8,1.7),.6);
        }
      }
      // Scorched outer perimeter, deliberately outside the walkway.
      const border = LOW ? 3 : 6;
      for(let k=0;k<border;k++){
        const side=k%2?1:-1;
        detail(k%3?MAT.wallDark:MAT.scorch,b.x+between(-b.w*.55,b.w*.55),.09,
          b.z+side*(b.d/2+between(.8,2.0)),between(.6,2.4),.14,between(.5,2),between(-.9,.9));
      }
    }
    // Collapsed manufactorum fragments and machine parts. Restrict to the
    // margins beyond the road corridors and limit all height to ankle level.
    for (let i=0; i<(LOW?80:166); i++) {
      let x,z;
      for(let trial=0;trial<12;trial++){
        x=between(-95,95);z=between(-102,102);
        if(Math.abs(x)>12 && Math.abs(z+33)>13)break;
      }
      if(Math.abs(x)<=12||Math.abs(z+33)<=13)continue;
      const w=between(.5,2.4), d=between(.5,2.2);
      detail(i%3 ? MAT.wallDark:MAT.wall, x, between(.07,.21),z,w,between(.12,.37),d,between(-Math.PI,Math.PI),between(-.06,.06));
      if(i%7===0) detail(MAT.steel,x+1.1,.22,z+.6,between(.3,.8),.26,between(1.1,2.8),between(-3,3));
    }
    // Fixed road cracks, tire abrasions and low-profile burn scars. No raised
    // meshes on lanes; keep their color contrast gentle for reticle readability.
    for(let i=0;i<(LOW?38:80);i++){
      const longitudinal=i%3!==0;
      const x=longitudinal?between(-6.7,6.7):between(-94,94);
      const z=longitudinal?between(-102,107):between(-40,-26);
      detail(i%4===0?MAT.earth:MAT.road,x,.065,z,
        longitudinal?between(.045,.12):between(.8,3.2),.009,
        longitudinal?between(1,4.4):between(.055,.13),between(-.18,.18));
    }
    // Emergency warning bands around the already-destructible reactor sites.
    for(const p of siege.props){
      if(p.type!=='REACTOR')continue;
      for(const sign of [-1,1]){
        for(let j=0;j<3;j++){
          detail(j===1?MAT.brass:MAT.panel,p.x+sign*2.4,.07,p.z+(j-1)*1.3,.24,.018,.74,sign*.5);
        }
      }
    }
    let sceneryCount=0;
    for(const [mat, entries] of groups){
      if(mat && entries.length){batch(mat,entries,'Alpha9 ruined-city detail');sceneryCount+=entries.length;}
    }

    // Actual battle damage leaves persistent, deterministic shrapnel and blast
    // scarring. Fixed capacity avoids allocating meshes on every destruction.
    const MAX_SCARS=48, MAX_FRAGMENTS=120;
    function pool(material, count, name){
      const inst=new InstancedMesh(boxGeo,material,count);
      inst.name=name;inst.count=0;inst.frustumCulled=false;
      inst.castShadow=false;inst.receiveShadow=false;
      scene.add(inst);sceneDetails.push(inst);return inst;
    }
    const scorches = pool(MAT.scorch || MAT.wallDark,MAX_SCARS,'Alpha9 persistent ground scars');
    const fragments = pool(MAT.wallDark,MAX_FRAGMENTS,'Alpha9 destroyed barricade shrapnel');
    const scarsByProp=new Set();
    const stages = new Map(siege.props.map(p=>[p, p.stage]));
    function emitScar(p){
      if(scarsByProp.has(p))return;
      scarsByProp.add(p);
      for(let i=0;i<4 && scorches.count<MAX_SCARS;i++){
        const a=rand()*Math.PI*2,rad=between(.9,p.type==='REACTOR'?5.5:3.3);
        scorches.setMatrixAt(scorches.count++,compose([
          p.x+Math.sin(a)*rad,.076,p.z+Math.cos(a)*rad,
          between(.85,2.6),.015,between(.7,2.2),between(-3,3)
        ]));
      }
      for(let i=0;i<(LOW?6:10) && fragments.count<MAX_FRAGMENTS;i++){
        const a=rand()*Math.PI*2,rad=between(1.2,p.type==='REACTOR'?6.4:3.9),s=between(.22,.65);
        fragments.setMatrixAt(fragments.count++,compose([
          p.x+Math.sin(a)*rad,s*.24,p.z+Math.cos(a)*rad,
          s*between(.7,1.65),s*.48,s*between(.6,1.5),between(-3,3),between(-.32,.32)
        ]));
      }
      scorches.instanceMatrix.needsUpdate=true;
      fragments.instanceMatrix.needsUpdate=true;
    }
    const resetOriginal=siege.reset;
    siege.reset=function(){
      const result=resetOriginal.apply(this,arguments);
      scorches.count=0;fragments.count=0;scarsByProp.clear();
      for(const p of siege.props)stages.set(p,0);
      return result;
    };

    // A subtle single-draw-call drifting ash field near the current view. The
    // mesh is repositioned at <=10Hz and produces no new object allocations.
    const ashCount=LOW?18:42;
    const ash=pool(MAT.bone,ashCount,'Alpha9 drifting ash');
    ash.count=ashCount;
    const flakes=Array.from({length:ashCount},()=>({
      dx:between(-27,27),dz:between(-27,27),y:between(1.2,15),size:between(.035,.11),phase:between(0,Math.PI*2)
    }));
    let tick=0,last=0,ashLast=0,alive=true;
    function update(now){
      if(!alive||window.__IC!==api)return;
      requestAnimationFrame(update);
      if(now-last<155) return; // cheap stage/event polling, not every frame
      const dt=Math.min(.3,Math.max(0,(now-last)/1000));last=now;
      const active=api.state?.mode==='playing';
      if(!active){ash.visible=false;return;}
      ash.visible=true;
      for(const p of siege.props){
        const prev=stages.get(p)??0, next=p.stage;
        if(next>prev){
          if(next>=2 && Math.hypot(p.x-camera.position.x,p.z-camera.position.z)<85){
            fx.dust(p.x,p.type==='REACTOR'?2.8:.75,p.z,p.type==='REACTOR'?2.8:1.7,LOW?3:6);
            if(next>=3) fx.sparks(p.x,p.type==='REACTOR'?2.4:1.0,p.z,0,1,0,LOW?5:10,9);
          }
          if(next>=3)emitScar(p);
        }
        stages.set(p,next);
      }
      if(now-ashLast>150){
        ashLast=now;
        for(let i=0;i<flakes.length;i++){
          const a=flakes[i];a.y+=dt*.28;
          if(a.y>15)a.y=1.1;
          const dx=Math.sin(now*.00022+a.phase)*1.1;
          ash.setMatrixAt(i,compose([
            camera.position.x+a.dx+dx,a.y,camera.position.z+a.dz,
            a.size,a.size*.4,a.size,now*.00012+a.phase
          ]));
        }
        ash.instanceMatrix.needsUpdate=true;
      }
    }
    requestAnimationFrame(update);
    api.alpha9={version:VERSION,kind:'instanced-battlefield-aftermath',enabled:true,visualOnly:true,
      mobile:LOW,sceneryInstances:sceneryCount,staticDrawCalls:groups.size,limitScars:MAX_SCARS,
      limitShrapnel:MAX_FRAGMENTS,features:['ruined-facades','rubble','road-scarring','reactor-warnings',
        'persistent-blast-scars','persistent-shrapnel','floating-ash','stage-impact-dust'],
      stats(){return{scars:scorches.count,shrapnel:fragments.count,ash:ash.count,scenery:sceneryCount};},
      destroy(){alive=false;sceneryCount=0;sceneDetails.forEach(mesh=>{scene.remove(mesh);mesh.dispose?.();});}
    };
  }
  function boot(){
    if(window.__IC){install(window.__IC);if(!window.__IC.alpha9)requestAnimationFrame(boot);}
    else requestAnimationFrame(boot);
  }
  boot();
})();
