/* Iron Crusade offline cache. Site-local; works at /iron-crusade-web/ or root. */
const VERSION = 'alpha9e-pwa-20261027-1';
const SHELL_CACHE = `iron-crusade-${VERSION}-shell`;
const ASSET_CACHE = `iron-crusade-${VERSION}-assets`;
const CACHE_PREFIX = 'iron-crusade-';
const OFFLINE_FILES = [
  "assets/alpha8-cinematics.js",
  "assets/alpha9-battlefield.js",
  "assets/alpha9b-expanse.js",
  "assets/alpha9c-expanse.js",
  "assets/alpha9d-expanse.js",
  "assets/alpha9e-expanse.js",
  "assets/game-55dZGtXX.js",
  "assets/game-B8xFdZ9J.css",
  "assets/game-Bu0f3myq.js",
  "assets/game-CKoXHPM7.js",
  "assets/game-DkVbmrcr.js",
  "assets/game-YYng6kzN.js",
  "assets/game-alpha9c-loader.js",
  "assets/game-alpha9c.js",
  "assets/game-alpha9d-loader.js",
  "assets/game-alpha9d.js",
  "assets/game-alpha9e-loader.js",
  "assets/game-alpha9e.js",
  "assets/game-iqsCVuep.js",
  "assets/modelAssets-BbQtIAZ4.js",
  "assets/modelAssets-CTgoLqxc.js",
  "assets/modelAssets-y09miYhk.js",
  "assets/models/ballistus/high.glb",
  "assets/models/ballistus/low.glb",
  "assets/models/ballistus/mid.glb",
  "assets/models/brutalis/high.glb",
  "assets/models/brutalis/low.glb",
  "assets/models/brutalis/mid.glb",
  "assets/models/redemptor/high.glb",
  "assets/models/redemptor/low.glb",
  "assets/models/redemptor/mid.glb",
  "assets/review-99qGP-sI.js",
  "assets/review-BqZah7So.js",
  "assets/review-CUIL3LHc.js",
  "assets/review-RK0-nooq.js",
  "assets/reviewScene-BgIKf045.js",
  "assets/reviewScene-Bmh_Py1L.js",
  "assets/reviewScene-CX3yjBfm.js",
  "assets/reviewScene-HRHLiqDa.js",
  "assets/warMachines-CxRsYVbZ.js",
  "assets/warMachines-KHC2rKOy.js",
  "assets/warMachines-TUyvP6ga.js",
  "assets/warMachines-alpha9d.js",
  "assets/warMachines-alpha9e.js",
  "icons/apple-touch-icon.png",
  "icons/favicon-64.png",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "index.html",
  "manifest.webmanifest",
  "offline-setup.html",
  "review.html"
];

const CORE_FILES = ['index.html','offline-setup.html','manifest.webmanifest','icons/icon-192.png','icons/apple-touch-icon.png'];
const urlFor = path => new URL(path, self.registration.scope).href;
function withinScope(request) {
  const u = new URL(request.url);
  return u.origin === self.location.origin && u.pathname.startsWith(new URL(self.registration.scope).pathname);
}
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(SHELL_CACHE);
    await Promise.all(CORE_FILES.map(p => cache.add(urlFor(p))));
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(x=>x.startsWith(CACHE_PREFIX)&&![SHELL_CACHE,ASSET_CACHE].includes(x)).map(x=>caches.delete(x)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if(request.method!=='GET'||!withinScope(request)) return;
  if (request.mode==='navigate') {
    event.respondWith((async () => {
      try {
        const fresh=await fetch(request);
        if(fresh.ok) {
          const cache=await caches.open(SHELL_CACHE);
          await cache.put(request,fresh.clone());
        }
        return fresh;
      } catch {
        return (await caches.match(request,{ignoreSearch:true})) ||
           (await caches.match(urlFor('index.html'))) ||
           new Response('Offline: open the app once while online and download the offline pack.',{status:503,headers:{'Content-Type':'text/plain'}});
      }
    })());
    return;
  }
  event.respondWith((async()=>{
    const cached=await caches.match(request,{ignoreSearch:true});
    if(cached)return cached;
    try {
      const response=await fetch(request);
      if(response.ok && new URL(request.url).origin===self.location.origin){
        const cache=await caches.open(ASSET_CACHE);
        await cache.put(request,response.clone());
      }
      return response;
    }catch{
      return new Response('Asset not yet cached for offline play',{status:503,headers:{'Content-Type':'text/plain'}});
    }
  })());
});
async function cachedStatus(){
  let done=0;
  for(const p of OFFLINE_FILES){
    if(await caches.match(urlFor(p),{ignoreSearch:true})) done++;
  }
  return {done,total:OFFLINE_FILES.length,ready:done===OFFLINE_FILES.length,version:VERSION};
}
self.addEventListener('message',event=>{
  const data=event.data||{};
  const port=event.ports&&event.ports[0];
  if(!port)return;
  const send=obj=>{try{port.postMessage(obj)}catch{}};
  if(data.type==='STATUS'){
    event.waitUntil(cachedStatus().then(result=>send({type:'status',...result})).catch(err=>send({type:'error',reason:String(err)})));
  }
  if(data.type==='PREPARE_OFFLINE'){
    event.waitUntil((async()=>{
      const cache=await caches.open(ASSET_CACHE);
      const remaining=[];let done=0;const errors=[];
      for(const p of OFFLINE_FILES){
        if(await caches.match(urlFor(p),{ignoreSearch:true}))done++;
        else remaining.push(p);
      }
      send({type:'progress',done,total:OFFLINE_FILES.length});
      let next=0;
      async function worker(){
        while(next<remaining.length){
          const path=remaining[next++];
          try{
            const url=urlFor(path);
            const response=await fetch(url,{cache:'reload'});
            if(!response.ok)throw new Error(`HTTP ${response.status}`);
            await cache.put(url,response);
            done++;
          }catch(err){errors.push({path,reason:String(err)})}
          send({type:'progress',done,total:OFFLINE_FILES.length,errorCount:errors.length});
        }
      }
      await Promise.all([worker(),worker(),worker()]);
      const status=await cachedStatus();
      send({type:'complete',...status,errors:errors.slice(0,10)});
    })().catch(err=>send({type:'error',reason:String(err)})));
  }
});
