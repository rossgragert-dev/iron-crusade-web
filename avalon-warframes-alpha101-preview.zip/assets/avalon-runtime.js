/* Avalon Warframes Alpha.10.1: standalone preview runtime, no external dependencies.
 * The production Alpha.9e PWA is unaffected. The RPG controller uses versioned local saves.
 */
(()=>{
'use strict';
const KEY='avalon_warframes_rpg_v1', MAX_LEVEL=30;
const BASE={level:1,xp:0,totalXp:0,sp:0,ranks:{mobility:0,melee:0,ordnance:0,defense:0},totalKills:0,missionRewards:0};
const getNeed=level=>100+(level-1)*55;
let save;
try{const raw=JSON.parse(localStorage.getItem(KEY)||'null');save={...BASE,...raw,ranks:{...BASE.ranks,...(raw?.ranks||{})}};}catch{save=structuredClone(BASE);}
function persist(){try{localStorage.setItem(KEY,JSON.stringify(save));}catch{}}
function gain(amount,kind){
 if(!Number.isFinite(amount)||amount<=0)return;
 save.totalXp+=amount;save.xp+=amount;
 let levelups=0;
 while(save.level<MAX_LEVEL&&save.xp>=getNeed(save.level)){save.xp-=getNeed(save.level);save.level++;save.sp++;levelups++;}
 if(save.level===MAX_LEVEL)save.xp=0;
 persist();render();
 if(levelups)notice('PILOT LEVEL '+save.level,'+'+levelups+' SKILL POINT'+(levelups===1?'':'S'));
 else if(kind==='kill')notice('+'+amount+' XP','HOSTILE DEFEATED');
}
let api=null, previousKills=0, prevFinished=false, lastChassis='', prevMode='';
let titleButton=null,panel=null,stat=null,progressbar=null;
let originalBase=null;
function notice(a,b){try{api?.hud?.notice(a,b,1.4);}catch{}}
function apply(){if(!api)return;
 for(const [key,frame] of Object.entries(api.machines)){
  if(!frame.available)continue;
  const tag='__avalon_base';
  if(!frame[tag])frame[tag]={shot:frame.abilities.primary.cadence,melee:frame.abilities.melee.cooldown,boost:frame.abilities.boost.cooldown,special:frame.abilities.special.cooldown};
  const b=frame[tag];
  frame.abilities.primary.cadence=Math.max(.085,b.shot*(1-save.ranks.ordnance*.045));
  frame.abilities.melee.cooldown=Math.max(.15,b.melee*(1-save.ranks.melee*.07));
  frame.abilities.boost.cooldown=Math.max(8,b.boost-save.ranks.mobility*.55);
  frame.abilities.special.cooldown=Math.max(2,b.special*(1-save.ranks.ordnance*.035));
 }
 for(const w of Object.values(api.walkers)){
  if(!w||!w.cfg)continue;
  w.cfg.boost.dash=5+save.ranks.mobility*.5;
 }
}
function spend(kind){if(!api||save.sp<1||!Object.hasOwn(save.ranks,kind)||save.ranks[kind]>=5)return;
 save.ranks[kind]++;save.sp--;persist();apply();render();notice('SKILL UPGRADED',kind.toUpperCase()+' RANK '+save.ranks[kind]);}
function makeUI(){
 const shell=document.createElement('div');shell.id='avalonRpg';shell.innerHTML=`<button id="avXp" aria-label="Open progression and skills" type="button">LV 1 · XP</button><section id="avPanel" hidden aria-label="Pilot skills"><div class="avHead"><b>AVALON PILOT · RPG TEST</b><button id="avClose" type="button">✕</button></div><p id="avStat"></p><div class="avRail"><div id="avProgress"></div></div><p class="avSmall">Earn XP from destroyed enemies and completed missions. One point per level.</p><div id="avSkills"></div><p class="avSmall">Skills and XP persist in this browser. New equipment, sword combat and original Sovereign QA chassis follow in the next milestone.</p><button id="avExport" type="button">EXPORT SAVE</button></section>`;
 document.body.appendChild(shell);titleButton=shell.querySelector('#avXp');panel=shell.querySelector('#avPanel');stat=shell.querySelector('#avStat');progressbar=shell.querySelector('#avProgress');
 const grid=shell.querySelector('#avSkills');
 for(const [key,label,detail] of [['mobility','MOBILITY','+0.5 s boost; faster recharge'],['ordnance','ORDNANCE','Primary/special cooldowns'],['melee','MELEE SERVOS','Melee attack recovery'],['defense','FIELD REPAIR','Regenerate hull during combat']]){
  const btn=document.createElement('button');btn.type='button';btn.dataset.skill=key;btn.innerHTML=`<b>${label}</b><small>${detail}</small><span></span>`;btn.onclick=()=>spend(key);grid.append(btn);
 }
 titleButton.addEventListener('pointerdown',event=>{event.stopPropagation();});
 titleButton.onclick=()=>{panel.hidden=!panel.hidden;render();};
 shell.querySelector('#avClose').onclick=()=>panel.hidden=true;
 shell.querySelector('#avExport').onclick=()=>{const blob=new Blob([JSON.stringify({schema:1,...save},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='avalon-warframes-pilot-save.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2500);};
 panel.addEventListener('pointerdown',event=>event.stopPropagation());
 render();
}
function render(){if(!titleButton)return;
 titleButton.textContent='LV '+save.level+' · XP '+(save.level===MAX_LEVEL?'MAX':save.xp+'/'+getNeed(save.level))+' · '+save.sp+' SP';
 stat.textContent='PILOT LEVEL '+save.level+'  |  '+save.sp+' SKILL POINTS  |  '+save.totalKills+' KILLS';
 progressbar.style.width=(save.level===MAX_LEVEL?100:Math.min(100,save.xp/getNeed(save.level)*100))+'%';
 panel.querySelectorAll('[data-skill]').forEach(b=>{const key=b.dataset.skill;b.disabled=save.sp<1||save.ranks[key]>=5;b.querySelector('span').textContent=save.ranks[key]+'/5';});
}
function connect(){if(!window.__IC)return false;api=window.__IC;
 // Preserve keyboard support while making the POV view switch its own touch pointer.
 const button=document.getElementById('viewToggle');
 if(button&&!button.dataset.avalonViewBound){button.dataset.avalonViewBound="1";button.onclick=null;button.style.touchAction='manipulation';button.addEventListener('pointerdown',event=>{if(event.pointerType==='mouse'&&event.button!==0)return;event.preventDefault();event.stopPropagation();api.switchCamera();});button.addEventListener('click',event=>{if(event.detail===0)api.switchCamera();});}
 makeUI();
 apply();
 patchAudio(api);
 window.__AVALON={progress:save,gainXP:gain,applyUpgrades:apply};
 previousKills=api.state.kills;prevFinished=api.state.finished;
 return true;
}
// Game's built-in sound bank remains for non-combat UI; new, quieter physics-based
// WAV preview effects replace the most conspicuous synthesized weapon and blast sounds.
function patchAudio(api){
 const names=['bolter','enemyFire','plasma','heavyFire','missile','explosion','bigExplosion','plasmaImpact','artillery'];
 const sounds=Object.create(null);let context=null,master=null,compressor=null;
 const AudioCtx=window.AudioContext||window.webkitAudioContext;
 const origPlay=api.audio.play.bind(api.audio);
 const cache=Object.create(null);
 async function init(){if(!AudioCtx)return;
  if(!context){context=new AudioCtx({latencyHint:'interactive'});compressor=context.createDynamicsCompressor();compressor.threshold.value=-12;compressor.ratio.value=4;master=context.createGain();master.gain.value=.60;master.connect(compressor).connect(context.destination);
   for(const kind of names)for(let v=0;v<2;v++){
    const path='./assets/audio/'+kind+'-'+v+'.wav';
    fetch(path).then(r=>r.ok?r.arrayBuffer():Promise.reject()).then(b=>context.decodeAudioData(b)).then(buf=>{(sounds[kind]||=[])[v]=buf;}).catch(()=>{});
   }
  }
  if(context.state!=='running')try{await context.resume();}catch{}
 }
 for(const ev of ['pointerdown','keydown'])document.addEventListener(ev,()=>{void init();},{capture:true,passive:true});
 const last=Object.create(null);
 api.audio.play=(kind,vol=1,pos=null)=>{
  if(!api.audio.enabled)return;
  const type=kind==='fire'?'bolter':kind;
  if(!names.includes(type))return origPlay(kind,Math.min(.85,vol),pos);
  if(!context||context.state!=='running'||!sounds[type]?.some(Boolean))return;
  const limit=kind==='bolter'||kind==='fire'?80:kind==='plasma'?90:kind==='heavyFire'?300:kind==='explosion'?180:80;
  const now=performance.now();if(now-(last[type]||-1e6)<limit)return;last[type]=now;
  let gain=vol*.75,pan=0;
  if(pos&&api.camera){const d=api.camera.position.distanceTo(pos);gain/=1+Math.pow(Math.max(0,d-6)/70,1.3);if(gain<.02)return;}
  const options=sounds[type].filter(Boolean);if(!options.length)return;
  const source=context.createBufferSource();source.buffer=options[Math.floor(Math.random()*options.length)];source.playbackRate.value=.97+Math.random()*.06;
  const output=context.createGain();output.gain.value=Math.min(.85,gain);source.connect(output).connect(master);source.start();
 };
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&context?.state==='running')context.suspend();});
 // Audio settings reflect the existing in-game sound toggle.
 window.__AVALON_AUDIO={isReady:()=>names.filter(n=>sounds[n]?.some(Boolean)),init};
}
let elapsed=0,lastTick=performance.now();function tick(){
 requestAnimationFrame(tick);if(!api)return;
 const now=performance.now(),dt=Math.min(.05,(now-lastTick)/1000);lastTick=now;
 const state=api.state;
 if(state.kills<previousKills)previousKills=state.kills; // a new/restarted mission
 if(state.kills>previousKills){for(let i=previousKills;i<state.kills;i++){save.totalKills++;gain(45,'kill');}previousKills=state.kills;persist();}
 if(state.finished&&!prevFinished&&state.kills>=6){save.missionRewards++;gain(150,'mission');}
 if(state.mode==='playing'){
   if(save.ranks.defense>0&&state.hp>0&&state.hp<100){state.hp=Math.min(100,state.hp+dt*save.ranks.defense*.3);api.walker.setIntegrity(state.hp/100);}
 }
 prevFinished=state.finished;
 if(state.mode!=='playing'&&state.kills===0)previousKills=0;
 if(api.chassis!==lastChassis){lastChassis=api.chassis;apply();}
 if(api.walker&&api.walker.cfg?.boost){const expected=5+save.ranks.mobility*.5;if(api.walker.cfg.boost.dash!==expected)api.walker.cfg.boost.dash=expected;}
 if(state.mode==='playing')document.getElementById('avalonRpg')?.classList.remove('inMenu');else document.getElementById('avalonRpg')?.classList.add('inMenu');
}
const ready=setInterval(()=>{if(connect()){clearInterval(ready);lastTick=performance.now();requestAnimationFrame(tick);}},70);
})();
